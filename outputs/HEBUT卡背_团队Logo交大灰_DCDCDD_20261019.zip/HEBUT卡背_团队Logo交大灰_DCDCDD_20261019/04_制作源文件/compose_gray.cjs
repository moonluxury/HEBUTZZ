const fs=require('fs');
const path=require('path');
const {execFileSync}=require('child_process');
const root=path.resolve(__dirname,'..');
const layers=path.join(root,'03_分层素材');
const work=path.resolve(root,'../hebut_cards_work/team_logo_exact_gray');
fs.mkdirSync(work,{recursive:true});
const magick='F:/ImageMagick-7.1.2-Q16-HDRI/magick.exe';
const color='#DCDCDD';
function m(a){return execFileSync(magick,a.map(String),{maxBuffer:32e6,env:{...process.env,MAGICK_THREAD_LIMIT:'2'}});}
function save(a,p){m([...a,'-strip','-depth','8','-define','png:color-type=6',p]);}
function place(a,p,x=0,y=0){a.push(p,'-gravity','NorthWest','-geometry',`+${x}+${y}`,'-compose','Over','-composite');}
const alphaSource=path.join(__dirname,'original_logo_alpha_source.png');
const mark=path.join(layers,'logo_layer.png');
// Render the existing editable logo layer as a single spot color; preserve its alpha and coordinates.
save([alphaSource,'-channel','RGB','-fill',color,'-colorize','100','+channel'],mark);
const bg=path.join(layers,'background_layer.png');
const base=path.join(layers,'card_back_base.png');
const frame=path.join(layers,'card_back_frame.png');
const type=path.join(layers,'text.png');
const final=path.join(root,'01_独立卡背/HEBUT_交大灰Logo卡背.png');
const a=[base];place(a,bg);place(a,mark);place(a,frame);place(a,type);save(a,final);
const a0=[base];place(a0,bg);place(a0,mark);place(a0,frame);save(a0,path.join(root,'01_独立卡背/HEBUT_交大灰Logo卡背_无字.png'));
const bbox=m([mark,'-alpha','extract','-threshold','8%','-format','%@','info:']).toString().trim();
save([mark,'-crop',bbox,'+repage'],path.join(root,'02_视觉素材/团队Logo_DCDCDD_透明.png'));
const b64=p=>fs.readFileSync(p).toString('base64');
const body=p=>fs.readFileSync(p,'utf8').replace(/^<svg[^>]*>/,'').replace(/<\/svg>\s*$/,'');
const prefix='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="1024" height="1536" viewBox="0 0 1024 1536">';
const svg=prefix+`<defs><filter id="logo-spot-color" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB"><feFlood flood-color="${color}"/><feComposite in2="SourceAlpha" operator="in"/></filter></defs>
<g id="base" inkscape:groupmode="layer" inkscape:label="底卡"><rect x="8" y="8" width="1008" height="1520" rx="70" fill="#f7f4e8"/></g>
<g id="background" inkscape:groupmode="layer" inkscape:label="原蓝紫背景"><image width="1024" height="1536" xlink:href="data:image/png;base64,${b64(bg)}"/></g>
<g id="team-logo" inkscape:groupmode="layer" inkscape:label="Logo · 单色 #DCDCDD"><image width="1024" height="1536" filter="url(#logo-spot-color)" xlink:href="data:image/png;base64,${b64(alphaSource)}"/></g>
<g id="frame" inkscape:groupmode="layer" inkscape:label="统一卡框">${body(path.join(layers,'card_back_frame.svg'))}</g>`+body(path.join(layers,'text.svg'))+'</svg>';
fs.writeFileSync(path.join(layers,'HEBUT_交大灰Logo卡背_layered.svg'),svg);
const preview=['-size','1700x1430','xc:#E8EEF2'];
function label(s,size,file){const p=path.join(work,file+'.png');save(['-background','none','-fill','#244d70','-font','C:/Windows/Fonts/msyhbd.ttc','-pointsize',size,'label:'+s],p);return p;}
place(preview,label('HEBUT 空天探索 · 交大灰 Logo 卡背',46,'title'),65,38);
place(preview,label('Logo 单一色值 #DCDCDD · 保留原图形与透明区域',25,'subtitle'),68,115);
const old=path.resolve(root,'../HEBUT卡背_团队Logo版_20261019/01_独立卡背/HEBUT_团队Logo卡背.png');
preview.push('(',old,'-resize','700x1050',')','-geometry','+95+215','-compose','Over','-composite');
preview.push('(',final,'-resize','700x1050',')','-geometry','+905+215','-compose','Over','-composite');
place(preview,label('原版 · 深蓝标识',30,'old-label'),335,1300);
place(preview,label('新版 · #DCDCDD',30,'new-label'),1130,1300);
save(preview,path.join(root,'00_交大灰前后对比.png'));
const alphaCheck=m([alphaSource,mark,'-alpha','extract','-compose','Difference','-composite','-format','%[fx:maxima]','info:']).toString().trim();
const colorCheck=m([mark,'-alpha','off','-format','%c','histogram:info:']).toString().trim();
fs.writeFileSync(path.join(__dirname,'verification.json'),JSON.stringify({logoColor:color,rgb:[220,220,221],alphaDifference:Number(alphaCheck),rgbHistogram:colorCheck,canvas:[1024,1536],source:alphaSource,method:'existing layer spot-color fill, no logo regeneration'},null,2));
console.log(JSON.stringify({final,logoColor:color,alphaDifference:alphaCheck,rgbHistogram:colorCheck},null,2));
